<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}
class MascoCustomPosts
{
	function __construct()
	{
		add_action('admin_menu', array($this, 'masco_header_footer_menu'));
		// Header
		add_action('init', array($this, 'masco_header'));
		add_action('init', array($this, 'masco_footer'));

		if(masco_check_cpt('megamenu')){
			add_action('init', array($this, 'masco_megamenu'));
		}

		// Portfolios
		if (masco_check_cpt('portfolio')) {
			add_action('init', array($this, 'masco_portfolio'));
			add_action('init', array($this, 'masco_portfolio_category'));
			add_action('init', array($this, 'masco_portfolio_tags'));
		}


		// team
		if (masco_check_cpt('team')) {
			add_action('init', array($this, 'masco_team'));
		}

		// services
		if (masco_check_cpt('service')) {
			add_action('init', array($this, 'masco_service'));
			add_action('init', array($this, 'masco_service_category'));
			add_action('init', array($this, 'masco_service_tags'));
		}

		// crypto
		// if (masco_check_cpt('crypto')) {
		// 	add_action('init', array($this, 'masco_crypto'));
		// 	add_action('init', array($this, 'masco_crypto_category'));
		// 	add_action('init', array($this, 'masco_crypto_tags'));
		// }

		
		// job
		if (masco_check_cpt('job')) {
			add_action('init', array($this, 'masco_job'));
			add_action('init', array($this, 'masco_job_category'));
			add_action('init', array($this, 'masco_job_tags'));
			add_action('init', array($this, 'masco_job_location'));
		}

		// Testimonial
		// if (masco_check_cpt('testimonial')) {
		// 	add_action('init', array($this, 'masco_testimonial'));
		// }


		// Case Study
		if (masco_check_cpt('case-study')) {
			add_action('init', array($this, 'masco_case_study'));
			add_action('init', array($this, 'masco_case_study_category'));
			add_action('init', array($this, 'masco_case_study_tags'));
		}
	}

	public function masco_header_footer_menu()
	{
		add_menu_page(
			'Header & Footer',
			'Header & Footer',
			'read',
			'header-footer',
			'',
			'dashicons-archive',
			40
		);
	}
	/**
	 *
	 * Masco Header Footer Post Type
	 *
	 */
	public function masco_header()
	{
		$labels = array(
			'name'               => _x('Header', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Header', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Header', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Header', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Header', 'masco-hp'),
			'add_new_item'       => __('Add New Header', 'masco-hp'),
			'new_item'           => __('New Header', 'masco-hp'),
			'edit_item'          => __('Edit Header', 'masco-hp'),
			'view_item'          => __('View Header', 'masco-hp'),
			'all_items'          => __('All Headers', 'masco-hp'),
			'search_items'       => __('Search Headers', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Headers found.', 'masco-hp'),
			'not_found_in_trash' => __('No Headers found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'show_in_menu' 		 => 'header-footer',
			'rewrite'            => array('slug' => 'header'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('masco_header', $args);
	}

	public function masco_footer()
	{
		$labels = array(
			'name'               => _x('Footer', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Footer', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Footer', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Footer', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Footer', 'masco-hp'),
			'add_new_item'       => __('Add New Footer', 'masco-hp'),
			'new_item'           => __('New Footer', 'masco-hp'),
			'edit_item'          => __('Edit Footer', 'masco-hp'),
			'view_item'          => __('View Footer', 'masco-hp'),
			'all_items'          => __('All Footers', 'masco-hp'),
			'search_items'       => __('Search Footers', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Footers found.', 'masco-hp'),
			'not_found_in_trash' => __('No Footers found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'footer'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('masco_footer', $args);
	}


	public function masco_megamenu()
	{
		$labels = array(
			'name'               => _x('Mega Menu', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Mega Menu', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Mega Menu', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Mega Menu', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Mega Menu', 'masco-hp'),
			'add_new_item'       => __('Add New Mega Menu', 'masco-hp'),
			'new_item'           => __('New Mega Menu', 'masco-hp'),
			'edit_item'          => __('Edit Mega Menu', 'masco-hp'),
			'view_item'          => __('View Mega Menu', 'masco-hp'),
			'all_items'          => __('All Mega Menus', 'masco-hp'),
			'search_items'       => __('Search Mega Menus', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Mega Menus found.', 'masco-hp'),
			'not_found_in_trash' => __('No Mega Menus found in Trash.', 'masco-hp')
		);

		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'megamenu'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			// 'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title', 'elementor', 'thumbnail',  'page-attributes')
		);
		register_post_type('masco_megamenu', $args);
	}

	/**
	 *
	 * masco Service Custom Post Type
	 *
	 */
	public function masco_service()
	{
		$labels = array(
			'name'               => _x('Service', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Service', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Service', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Service', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Service', 'masco-hp'),
			'add_new_item'       => __('Add New Service', 'masco-hp'),
			'new_item'           => __('New Service', 'masco-hp'),
			'edit_item'          => __('Edit Service', 'masco-hp'),
			'view_item'          => __('View Service', 'masco-hp'),
			'all_items'          => __('All Services', 'masco-hp'),
			'search_items'       => __('Search Services', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Services found.', 'masco-hp'),
			'not_found_in_trash' => __('No Services found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-megaphone',
			'rewrite'            => array('slug' => 'service', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('service', $args);
	}
	public function masco_service_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Categories', 'masco-hp'),
			'all_items'         => __('All Categories', 'masco-hp'),
			'parent_item'       => __('Parent Category', 'masco-hp'),
			'parent_item_colon' => __('Parent Category:', 'masco-hp'),
			'edit_item'         => __('Edit Category', 'masco-hp'),
			'update_item'       => __('Update Category', 'masco-hp'),
			'add_new_item'      => __('Add New Category', 'masco-hp'),
			'new_item_name'     => __('New Category Name', 'masco-hp'),
			'menu_name'         => __('Category', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'service-category'),
		);
		register_taxonomy('service-category', array('service'), $args);
	}
	public function masco_service_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Tags', 'masco-hp'),
			'all_items'         => __('All Tags', 'masco-hp'),
			'parent_item'       => __('Parent Tag', 'masco-hp'),
			'parent_item_colon' => __('Parent Tag:', 'masco-hp'),
			'edit_item'         => __('Edit Tag', 'masco-hp'),
			'update_item'       => __('Update Tag', 'masco-hp'),
			'add_new_item'      => __('Add New Tag', 'masco-hp'),
			'new_item_name'     => __('New Tag Name', 'masco-hp'),
			'menu_name'         => __('Tag', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'pf-tag'),
		);
		register_taxonomy('service-tag', array('service'), $args);
	}


	/**
	 *
	 * masco Cripto Custom Post Type
	 *
	 */
	public function masco_crypto()
	{
		$labels = array(
			'name'               => _x('Crypto', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Crypto', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Crypto', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Crypto', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Crypto', 'masco-hp'),
			'add_new_item'       => __('Add New Crypto', 'masco-hp'),
			'new_item'           => __('New Crypto', 'masco-hp'),
			'edit_item'          => __('Edit Crypto', 'masco-hp'),
			'view_item'          => __('View Crypto', 'masco-hp'),
			'all_items'          => __('All Cryptos', 'masco-hp'),
			'search_items'       => __('Search Cryptos', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Cryptos found.', 'masco-hp'),
			'not_found_in_trash' => __('No Cryptos found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-money-alt',
			'rewrite'            => array('slug' => 'crypto', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('crypto', $args);
	}
	public function masco_crypto_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Categories', 'masco-hp'),
			'all_items'         => __('All Categories', 'masco-hp'),
			'parent_item'       => __('Parent Category', 'masco-hp'),
			'parent_item_colon' => __('Parent Category:', 'masco-hp'),
			'edit_item'         => __('Edit Category', 'masco-hp'),
			'update_item'       => __('Update Category', 'masco-hp'),
			'add_new_item'      => __('Add New Category', 'masco-hp'),
			'new_item_name'     => __('New Category Name', 'masco-hp'),
			'menu_name'         => __('Category', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'crypto-category'),
		);
		register_taxonomy('crypto-category', array('crypto'), $args);
	}
	public function masco_crypto_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Tags', 'masco-hp'),
			'all_items'         => __('All Tags', 'masco-hp'),
			'parent_item'       => __('Parent Tag', 'masco-hp'),
			'parent_item_colon' => __('Parent Tag:', 'masco-hp'),
			'edit_item'         => __('Edit Tag', 'masco-hp'),
			'update_item'       => __('Update Tag', 'masco-hp'),
			'add_new_item'      => __('Add New Tag', 'masco-hp'),
			'new_item_name'     => __('New Tag Name', 'masco-hp'),
			'menu_name'         => __('Tag', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'crypto-tag'),
		);
		register_taxonomy('crypto-tag', array('crypto'), $args);
	}

	/**
	 *
	 * Masco Team Post Type
	 *
	 */
	public function masco_team()
	{
		$labels = array(
			'name'               => _x('Team Member', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Team Member', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Team Member', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Team Member', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Member', 'masco-hp'),
			'add_new_item'       => __('Add New Member', 'masco-hp'),
			'new_item'           => __('New Member', 'masco-hp'),
			'edit_item'          => __('Edit Member', 'masco-hp'),
			'view_item'          => __('View Member', 'masco-hp'),
			'all_items'          => __('All Team Members', 'masco-hp'),
			'search_items'       => __('Search Team Members', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Team Members found.', 'masco-hp'),
			'not_found_in_trash' => __('No Team Members found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'team', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail', 'elementor',  'page-attributes')
		);
		register_post_type('team', $args);
	}

	/**
	 *
	 * Masco Portfolio Post Type
	 *
	 */
	public function masco_portfolio()
	{
		$labels = array(
			'name'               => _x('Portfolio', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Portfolio', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Portfolio', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Portfolio', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Portfolio', 'masco-hp'),
			'add_new_item'       => __('Add New Portfolio', 'masco-hp'),
			'new_item'           => __('New Portfolio', 'masco-hp'),
			'edit_item'          => __('Edit Portfolio', 'masco-hp'),
			'view_item'          => __('View Portfolio', 'masco-hp'),
			'all_items'          => __('All Portfolios', 'masco-hp'),
			'search_items'       => __('Search Portfolios', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Portfolios found.', 'masco-hp'),
			'not_found_in_trash' => __('No Portfolios found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'portfolio', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('portfolio', $args);
	}
	public function masco_portfolio_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Categories', 'masco-hp'),
			'all_items'         => __('All Categories', 'masco-hp'),
			'parent_item'       => __('Parent Category', 'masco-hp'),
			'parent_item_colon' => __('Parent Category:', 'masco-hp'),
			'edit_item'         => __('Edit Category', 'masco-hp'),
			'update_item'       => __('Update Category', 'masco-hp'),
			'add_new_item'      => __('Add New Category', 'masco-hp'),
			'new_item_name'     => __('New Category Name', 'masco-hp'),
			'menu_name'         => __('Category', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-category'),
		);
		register_taxonomy('portfolio-category', array('portfolio'), $args);
	}
	public function masco_portfolio_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Tags', 'masco-hp'),
			'all_items'         => __('All Tags', 'masco-hp'),
			'parent_item'       => __('Parent Tag', 'masco-hp'),
			'parent_item_colon' => __('Parent Tag:', 'masco-hp'),
			'edit_item'         => __('Edit Tag', 'masco-hp'),
			'update_item'       => __('Update Tag', 'masco-hp'),
			'add_new_item'      => __('Add New Tag', 'masco-hp'),
			'new_item_name'     => __('New Tag Name', 'masco-hp'),
			'menu_name'         => __('Tag', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-tag'),
		);
		register_taxonomy('portfolio-tag', array('portfolio'), $args);
	}

	/**
	 *
	 * Masco Job Post Type
	 *
	 */
	public function masco_job()
	{
		$labels = array(
			'name'               => _x('Job', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Job', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Job', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Job', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Job', 'masco-hp'),
			'add_new_item'       => __('Add New Job', 'masco-hp'),
			'new_item'           => __('New Job', 'masco-hp'),
			'edit_item'          => __('Edit Job', 'masco-hp'),
			'view_item'          => __('View Job', 'masco-hp'),
			'all_items'          => __('All Jobs', 'masco-hp'),
			'search_items'       => __('Search Jobs', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Jobs found.', 'masco-hp'),
			'not_found_in_trash' => __('No Jobs found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'job', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('job', $args);
	}
	public function masco_job_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Categories', 'masco-hp'),
			'all_items'         => __('All Categories', 'masco-hp'),
			'parent_item'       => __('Parent Category', 'masco-hp'),
			'parent_item_colon' => __('Parent Category:', 'masco-hp'),
			'edit_item'         => __('Edit Category', 'masco-hp'),
			'update_item'       => __('Update Category', 'masco-hp'),
			'add_new_item'      => __('Add New Category', 'masco-hp'),
			'new_item_name'     => __('New Category Name', 'masco-hp'),
			'menu_name'         => __('Category', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-category'),
		);
		register_taxonomy('job-category', array('job'), $args);
	}
	public function masco_job_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Tags', 'masco-hp'),
			'all_items'         => __('All Tags', 'masco-hp'),
			'parent_item'       => __('Parent Tag', 'masco-hp'),
			'parent_item_colon' => __('Parent Tag:', 'masco-hp'),
			'edit_item'         => __('Edit Tag', 'masco-hp'),
			'update_item'       => __('Update Tag', 'masco-hp'),
			'add_new_item'      => __('Add New Tag', 'masco-hp'),
			'new_item_name'     => __('New Tag Name', 'masco-hp'),
			'menu_name'         => __('Tag', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-tag'),
		);
		register_taxonomy('job-tag', array('job'), $args);
	}
	public function masco_job_location()
	{
		$labels = array(
			'name'              => _x('Job Locations', 'taxonomy general name', 'shadepro-ts'),
			'singular_name'     => _x('Job Location', 'taxonomy singular name', 'shadepro-ts'),
			'search_items'      => __('Search Job Locations', 'shadepro-ts'),
			'all_items'         => __('All Job Locations', 'shadepro-ts'),
			'parent_item'       => __('Parent Job Location', 'shadepro-ts'),
			'parent_item_colon' => __('Parent Job Location:', 'shadepro-ts'),
			'edit_item'         => __('Edit Job Location', 'shadepro-ts'),
			'update_item'       => __('Update Job Location', 'shadepro-ts'),
			'add_new_item'      => __('Add New Job Location', 'shadepro-ts'),
			'new_item_name'     => __('New Job Location Name', 'shadepro-ts'),
			'menu_name'         => __('Job Location', 'shadepro-ts'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-location'),
		);
		register_taxonomy('job-location', array('job'), $args);
	}
	//Testimonial
	public function masco_testimonial()
	{
		$labels = array(
			'name'               => _x('Testimonial', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Testimonial', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Testimonial', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Testimonial', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Testimonial', 'masco-hp'),
			'add_new_item'       => __('Add New Testimonial', 'masco-hp'),
			'new_item'           => __('New Testimonial', 'masco-hp'),
			'edit_item'          => __('Edit Testimonial', 'masco-hp'),
			'view_item'          => __('View Testimonial', 'masco-hp'),
			'all_items'          => __('All Testimonial', 'masco-hp'),
			'search_items'       => __('Search Testimonial', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Testimonial found.', 'masco-hp'),
			'not_found_in_trash' => __('No Testimonial found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-testimonial',
			'rewrite'            => array('slug' => 'masco_testimonial', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('masco_testimonial', $args);
	}
	public function masco_testimonial_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Categories', 'masco-hp'),
			'all_items'         => __('All Categories', 'masco-hp'),
			'parent_item'       => __('Parent Category', 'masco-hp'),
			'parent_item_colon' => __('Parent Category:', 'masco-hp'),
			'edit_item'         => __('Edit Category', 'masco-hp'),
			'update_item'       => __('Update Category', 'masco-hp'),
			'add_new_item'      => __('Add New Category', 'masco-hp'),
			'new_item_name'     => __('New Category Name', 'masco-hp'),
			'menu_name'         => __('Category', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-category'),
		);
		register_taxonomy('testimonial_category', array('masco_testimonial'), $args);
	}
	public function masco_testimonial_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Tags', 'masco-hp'),
			'all_items'         => __('All Tags', 'masco-hp'),
			'parent_item'       => __('Parent Tag', 'masco-hp'),
			'parent_item_colon' => __('Parent Tag:', 'masco-hp'),
			'edit_item'         => __('Edit Tag', 'masco-hp'),
			'update_item'       => __('Update Tag', 'masco-hp'),
			'add_new_item'      => __('Add New Tag', 'masco-hp'),
			'new_item_name'     => __('New Tag Name', 'masco-hp'),
			'menu_name'         => __('Tag', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-tag'),
		);
		register_taxonomy('testimonial_tag', array('masco_testimonial'), $args);
	}

	//Case Study

	public function masco_case_study()
	{
		$labels = array(
			'name'               => _x('Case Study', 'post type general name', 'masco-hp'),
			'singular_name'      => _x('Case Study', 'post type singular name', 'masco-hp'),
			'menu_name'          => _x('Case Study', 'admin menu', 'masco-hp'),
			'name_admin_bar'     => _x('Case Study', 'add new on admin bar', 'masco-hp'),
			'add_new'            => __('Add New Studies', 'masco-hp'),
			'add_new_item'       => __('Add New Studies', 'masco-hp'),
			'new_item'           => __('New Studies', 'masco-hp'),
			'edit_item'          => __('Edit Studies', 'masco-hp'),
			'view_item'          => __('View Studies', 'masco-hp'),
			'all_items'          => __('All Studies', 'masco-hp'),
			'search_items'       => __('Search Studies', 'masco-hp'),
			'parent_item_colon'  => __('Parent :', 'masco-hp'),
			'not_found'          => __('No Studies found.', 'masco-hp'),
			'not_found_in_trash' => __('No Studies found in Trash.', 'masco-hp')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'masco-hp'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-media-spreadsheet',
			'rewrite'            => array('slug' => 'case-studies', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'excerpt', 'thumbnail',  'page-attributes')
		);
		register_post_type('case-study', $args);
	}

	public function masco_case_study_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Categories', 'masco-hp'),
			'all_items'         => __('All Categories', 'masco-hp'),
			'parent_item'       => __('Parent Category', 'masco-hp'),
			'parent_item_colon' => __('Parent Category:', 'masco-hp'),
			'edit_item'         => __('Edit Category', 'masco-hp'),
			'update_item'       => __('Update Category', 'masco-hp'),
			'add_new_item'      => __('Add New Category', 'masco-hp'),
			'new_item_name'     => __('New Category Name', 'masco-hp'),
			'menu_name'         => __('Category', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'studies_category'),
		);
		register_taxonomy('case-study-category', array('case-study'), $args);
	}

	public function masco_case_study_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'masco-hp'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'masco-hp'),
			'search_items'      => __('Search Tags', 'masco-hp'),
			'all_items'         => __('All Tags', 'masco-hp'),
			'parent_item'       => __('Parent Tag', 'masco-hp'),
			'parent_item_colon' => __('Parent Tag:', 'masco-hp'),
			'edit_item'         => __('Edit Tag', 'masco-hp'),
			'update_item'       => __('Update Tag', 'masco-hp'),
			'add_new_item'      => __('Add New Tag', 'masco-hp'),
			'new_item_name'     => __('New Tag Name', 'masco-hp'),
			'menu_name'         => __('Tag', 'masco-hp'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'studies-tag'),
		);
		register_taxonomy('studies-tag', array('case-study'), $args);
	}
}
$mascoCcases_stydyInstance = new MascoCustomPosts;
