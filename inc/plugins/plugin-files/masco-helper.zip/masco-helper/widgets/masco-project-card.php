<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Masco_Project_Card_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'masco_project_card';
	}

	public function get_title() {
		return esc_html__( 'Masco Project Card', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control('per_line', [
			'label'              => __('Columns per row', 'masco-hp'),
			'type'               => \Elementor\Controls_Manager::SELECT,
			'default'            => '3',
			'tablet_default'     => '6',
			'tablet_extra'     => '6',
			'mobile_default'     => '12',
			'options'            => [
					'12' => '1',
					'6'  => '2',
					'4'  => '3',
					'3'  => '4',
			],
			'frontend_available' => true,
	]);

	$this->add_control(
		'show_slider_settings',
				[
						'label' => __('Slider Active', 'finisys'),
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => __('Yes', 'finisys'),
						'label_off' => __('No', 'finisys'),
						'return_value' => 'yes',
						'default' => 'no',
				]
		);

    $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'masco_card_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'masco_card_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Default title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_card_description',
			[
				'label' => esc_html__( 'Publice Sale Date', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'masco_card_price_title',
			[
				'label' => esc_html__( 'Price Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Price Title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => false,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_card_price',
			[
				'label' => esc_html__( 'Price', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => false
			]
		);
		
		$repeater->add_control(
			'masco_card_btn',
			[
				'label' => esc_html__( 'Button', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_card_btn_link',
			[
				'label' => esc_html__( 'Link', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'masco-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'masco_card_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'masco_card_thumb' => esc_html__( 'Image', 'masco-hp' ),
						'masco_card_title' => esc_html__( 'Meta Frog Club: VIP Sale', 'masco-hp' ),
						'masco_card_description' => esc_html__( 'Pre-sale : 18 May 2023', 'masco-hp' ),
						'masco_card_price_Title' => esc_html__( 'Mint Price:', 'masco-hp' ),
						'masco_card_price' => esc_html__( '0.194 ETH', 'masco-hp' ),
						'masco_card_btn' => esc_html__( 'Place a Bid', 'masco-hp' ),
						'masco_card_btn_link' => esc_html__( '#', 'masco-hp' ),
					],
				
				],
				'title_field' => '{{{ masco_card_title }}}',
			]
		);


		$this->end_controls_section();

		// slider arrow

		$this->start_controls_section(
			'slider_content_section',
			[
				'label' => esc_html__( 'Arrows', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'arrow_prev_icon',
			[
				'label' => esc_html__( 'Slider Icon Left', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'arrow_next_icon',
			[
				'label' => esc_html__( 'Slider Icon Right', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->end_controls_section();

		// slider Setting

		$this->start_controls_section(
			'slider_setting_section',
			[
				'label' => esc_html__( 'Setting', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
					'label' => __('Auto Play?', 'masco-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'masco-hp'),
					'label_off' => __('Hide', 'masco-hp'),
					'return_value' => 'yes',
					'default' => 'yes',
			]
	);
	$this->add_control(
		'arrows',
		[
				'label' => __('Show arrows?', 'masco-hp'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __('Show', 'masco-hp'),
				'label_off' => __('Hide', 'masco-hp'),
				'return_value' => 'yes',
				'default' => 'no',
		]
);



		$this->end_controls_section();

				// start style parts

			// Image
			$this->start_controls_section(
				'card_image_style',
				[
					'label' => esc_html__( 'Image', 'masco-hp' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_responsive_control(
				'card_iamge_width',
				[
					'label' => esc_html__( 'Width', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 100,
					],
					'selectors' => [
						'{{WRAPPER}} .masco-card-thumb img' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'card_height_width',
				[
					'label' => esc_html__( 'Height', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 100,
					],
					'selectors' => [
						'{{WRAPPER}} .masco-card-thumb img' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

	
			$this->add_control(
				'card_image_border_radius',
				[
					'label' => esc_html__( 'Border Radius', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .masco-card-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before'
				]
			);
			$this->end_controls_section();
			// end image style

			// Title
		$this->start_controls_section(
			'card_title_style',
			[
				'label' => esc_html__( 'Title', 'simple-team-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'card_title_color',
			[
				'label' => esc_html__( 'Color', 'simple-team-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-card-data h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'card_title_typography',
				'selector' => '{{WRAPPER}} .masco-card-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'card_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'simple-team-addon' ),
				'selector' => '{{WRAPPER}} .masco-card-data h3',
			]
		);

		$this->add_control(
			'card_title_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-data h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End title style

			// Descriptions 
			$this->start_controls_section(
				'card_descriptions_style',
				[
					'label' => esc_html__( 'Description', 'simple-team-addon' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
			$this->add_control(
				'card_descriptions_color',
				[
					'label' => esc_html__( 'Color', 'simple-team-addon' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masco-card-data p' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'card_descriptions_typography',
					'selector' => '{{WRAPPER}} .masco-card-data p',
				]
			);
	
			$this->add_group_control(
				\Elementor\Group_Control_Text_Shadow::get_type(),
				[
					'name' => 'card_descriptions_text_shadow',
					'label' => esc_html__( 'Text Shadow', 'simple-team-addon' ),
					'selector' => '{{WRAPPER}} .masco-card-data p',
				]
			);
	
			$this->add_control(
				'card_descriptions_margin',
				[
					'label' => esc_html__( 'Margin', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .masco-card-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
	
			$this->end_controls_section();
			// End title style

			// Price 
			$this->start_controls_section(
				'card_price_style',
				[
					'label' => esc_html__( 'Price Title', 'simple-team-addon' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
			$this->add_control(
				'card_price_color',
				[
					'label' => esc_html__( 'Color', 'simple-team-addon' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masco-card-footer-data span' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'card_price_typography',
					'selector' => '{{WRAPPER}} .masco-card-footer-data span',
				]
			);
	
			$this->add_group_control(
				\Elementor\Group_Control_Text_Shadow::get_type(),
				[
					'name' => 'card_price_text_shadow',
					'label' => esc_html__( 'Text Shadow', 'simple-team-addon' ),
					'selector' => '{{WRAPPER}} .masco-card-footer-data span',
				]
			);
	
			$this->add_control(
				'card_price_margin',
				[
					'label' => esc_html__( 'Margin', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .masco-card-footer-data span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
	
			$this->end_controls_section();
			// End price style

			// Price 
			$this->start_controls_section(
				'card_price_data_style',
				[
					'label' => esc_html__( 'Price', 'simple-team-addon' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
			$this->add_control(
				'card_price_data_color',
				[
					'label' => esc_html__( 'Color', 'simple-team-addon' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masco-card-footer-data h4' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'card_price_data_typography',
					'selector' => '{{WRAPPER}} .masco-card-footer-data h4',
				]
			);
	
			$this->add_group_control(
				\Elementor\Group_Control_Text_Shadow::get_type(),
				[
					'name' => 'card_price_data_text_shadow',
					'label' => esc_html__( 'Text Shadow', 'simple-team-addon' ),
					'selector' => '{{WRAPPER}} .masco-card-footer-data h4',
				]
			);
	
			$this->add_control(
				'card_price_data_margin',
				[
					'label' => esc_html__( 'Margin', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .masco-card-footer-data h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
	
			$this->end_controls_section();
			// End title style


		// Button
		$this->start_controls_section(
			'card_btn_style',
			[
				'label' => esc_html__( 'Button', 'simple-team-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'card_btn_style_tabs'
		);

		$this->start_controls_tab(
			'btn_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'simple-team-addon' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'card_btn_typography',
				'selector' => '{{WRAPPER}} a.masco-card-btn',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'card_btn_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} a.masco-card-btn',
			]
		);

	
		$this->add_control(
			'card_btn_color',
			[
				'label' => esc_html__( 'Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.masco-card-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'card_btn_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} a.masco-card-btn',
			]
		);

		$this->add_control(
			'card_btn_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.masco-card-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'card_btn_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} a.masco-card-btn',
			]
		);

		$this->add_responsive_control(
			'card_btn_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.masco-card-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();


		// btn hover

		$this->start_controls_tab(
			'btn_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'simple-team-addon' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'card_hover_btn_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-card-wrap:hover a.masco-card-btn',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'card_hover_btn_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-card-wrap:hover a.masco-card-btn',
			]
		);


		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'card_hover_btn_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-card-wrap:hover a.masco-card-btn',
			]
		);

		$this->end_controls_tabs();
		
		$this->end_controls_section();

		// End button style


		// slider arrows
		$this->start_controls_section(
			'icon_style_section',
			[
				'label' => esc_html__( 'Arrows', 'card-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'arrows_style_tabs'
		);

		$this->start_controls_tab(
			'arrow_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'card-addon' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrow_background',
				'label' => esc_html__( 'Background', 'card-addon' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .card-slider-arrow button',
			]
		);

		$this->add_control(
			'arrow_fill_color',
			[
				'label' => esc_html__( 'Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .card-slider-arrow button path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_width',
			[
				'label' => esc_html__( 'Width', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				
				],
		
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'arrows_size',
			[
				'label' => esc_html__( 'Size', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .card-slider-arrow button svg' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'arrows_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'card-addon' ),
				'selector' => '{{WRAPPER}} .card-slider-arrow button',
			]
		);

		$this->end_controls_tab();

		// icon hover

		$this->start_controls_tab(
			'arrows_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'card-addon' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrows_hover_background',
				'label' => esc_html__( 'Background', 'card-addon' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .card-slider-arrow button:hover',
			]
		);

		$this->add_control(
			'arrows_hover_fill_color',
			[
				'label' => esc_html__( 'Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .card-slider-arrow button:hover path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrows_hover_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .card-slider-arrow button:hover path' => 'stroke: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'card-addon' ),
				'selector' => '{{WRAPPER}} .card-slider-arrow button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();


			// Card box
			$this->start_controls_section(
				'card_box_style',
				[
					'label' => esc_html__( 'Box', 'simple-team-addon' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
			$this->start_controls_tabs(
				'card_box_style_tabs'
			);
	
			$this->start_controls_tab(
				'box_style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'simple-team-addon' ),
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'card_box_background',
					'label' => esc_html__( 'Background', 'masco-hp' ),
					'types' => [ 'classic', 'gradient', 'video' ],
					'selector' => '{{WRAPPER}} .masco-card-wrap',
				]
			);
	
	
	
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'card_box_border',
					'label' => esc_html__( 'Border', 'masco-hp' ),
					'selector' => '{{WRAPPER}} .masco-card-wrap',
				]
			);
	
			$this->add_control(
				'card_box_border_radius',
				[
					'label' => esc_html__( 'Border Radius', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .masco-card-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before'
				]
			);
	
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'card_box_box_shadow',
					'label' => esc_html__( 'Box Shadow', 'masco-hp' ),
					'selector' => '{{WRAPPER}} .masco-card-wrap',
				]
			);
	
			$this->add_responsive_control(
				'card_box_padding',
				[
					'label' => esc_html__( 'Padding', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .masco-card-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
	
			$this->end_controls_tab();
	
	
			// btn hover
	
			$this->start_controls_tab(
				'box_style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'simple-team-addon' ),
				]
			);
	
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'card_hover_box_background',
					'label' => esc_html__( 'Background', 'masco-hp' ),
					'types' => [ 'classic', 'gradient', 'video' ],
					'selector' => '{{WRAPPER}} .masco-card-wrap:hover',
				]
			);
	
		
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'card_hover_box_border',
					'label' => esc_html__( 'Border', 'masco-hp' ),
					'selector' => '{{WRAPPER}} .masco-card-wrap:hover',
				]
			);
	
	
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'card_hover_box_box_shadow',
					'label' => esc_html__( 'Box Shadow', 'masco-hp' ),
					'selector' => '{{WRAPPER}} .masco-card-wrap:hover',
				]
			);
	
			$this->end_controls_tabs();
			
			$this->end_controls_section();
	
			// End button style

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$masco_card_list = $settings['masco_card_list'];
		$arrow_prev_icon = $settings['arrow_prev_icon'];
		$arrow_next_icon = $settings['arrow_next_icon'];

		 //this code slider option
		 $slider_extraSetting = array(

			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			// 'arrows' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);
	

		if (('yes' == $settings['show_slider_settings'])) {
			$this->add_render_attribute('masco_card_version', 'class', array('masco-slider-one', 't-style'));
			$this->add_render_attribute('masco_card_version', 'data-settings', $jasondecode);

		
	} else {
			$this->add_render_attribute('masco_card_version', 'class', array('row g-0 justify-content-center'));
			//gride class
			$grid_classes = [];
			$grid_classes[] = 'col-xl-' . $settings['per_line'];
			$grid_classes[] = 'col-md-' . $settings['per_line_tablet'];
			$grid_classes[] = 'col-sm-' . $settings['per_line_mobile'];
			$grid_classes = implode(' ', $grid_classes);
			$this->add_render_attribute('masco_card_classes', 'class', [$grid_classes, 'col-lg-6']);
		}

		?>

    <div <?php echo $this->get_render_attribute_string('masco_card_version'); ?>>
			<?php foreach ($masco_card_list as $masco_card_lists) : ?>
				<div <?php echo $this->get_render_attribute_string('masco_card_classes'); ?>>
				<div class="masco-card-wrap">
						<div class="masco-card-thumb">
							<img src="<?php echo esc_url($masco_card_lists['masco_card_thumb']['url']) ?>" alt="">
						</div>
						<div class="masco-card-data">
							<h3><?php echo esc_html($masco_card_lists['masco_card_title']) ?></h3>
							<p><?php echo esc_html($masco_card_lists['masco_card_description']) ?></p>
							<div class="masco-card-footer">
								<div class="masco-card-footer-data">
									<span><?php echo esc_html($masco_card_lists['masco_card_price_title']) ?></span>
									<h4><?php echo esc_html($masco_card_lists['masco_card_price']) ?></h4>
								</div>
								<?php if (!empty($masco_card_lists['masco_card_btn'])) : ?>
									<a class="masco-card-btn" href="<?php echo esc_url($masco_card_lists['masco_card_btn_link']['url']) ?>"><?php echo esc_html($masco_card_lists['masco_card_btn']) ?></a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
					
			<?php endforeach; ?>
    </div>


		<?php if ('yes' == $settings['show_slider_settings'] && 'yes' == $settings['arrows']) : ?>
				<div class="card-slider-arrow">
					<?php if (!empty($settings['arrow_prev_icon']['value'])) : ?>
							<button type="button" class="slick-prev prev slick-arrow slick-active">
									<?php \Elementor\Icons_Manager::render_icon($arrow_prev_icon, ['aria-hidden' => 'true']);?>
							</button>
					<?php endif; ?>

					<?php if (!empty($settings['arrow_next_icon']['value'])) : ?>
							<button type="button" class="slick-next next slick-arrow ">
									<?php \Elementor\Icons_Manager::render_icon($arrow_next_icon, ['aria-hidden' => 'true']);?>
							</button>
					<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php
   
  }

}

$widgets_manager->register( new \Masco_Project_Card_Widget() );