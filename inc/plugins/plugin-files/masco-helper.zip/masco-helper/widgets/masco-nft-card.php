<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Masco_Nft_Card_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'masco_nft_slider';
	}

	public function get_title() {
		return esc_html__( 'Masco Nft Card', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);



    $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'masco_nft_card_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'masco_nft_card_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Default title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_nft_card_price',
			[
				'label' => esc_html__( 'Price', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'masco_nft_card_price_icon',
			[
				'label' => esc_html__( 'Price Icon', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$repeater->add_control(
			'masco_nft_card_author',
			[
				'label' => esc_html__( 'Author', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Price Title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => false,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_nft_card_button',
			[
				'label' => esc_html__( 'Button', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Button', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => false,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_nft_card_button_icon',
			[
				'label' => esc_html__( 'Button Icon', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'masco_nft_card_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'masco_nft_card_thumb' => esc_html__( 'Image', 'masco-hp' ),
						'masco_nft_card_title' => esc_html__( 'ApeSmilling: VIP Sale', 'masco-hp' ),
						'masco_nft_card_price' => esc_html__( '0.286 ETH', 'masco-hp' ),
						'masco_nft_card_price_icon' => esc_html__( 'Icon', 'masco-hp' ),
						'masco_nft_card_author' => esc_html__( 'By Jones', 'masco-hp' ),
					],
				
				],
				'title_field' => '{{{ masco_nft_card_title }}}',
			]
		);

		$this->end_controls_section();

		// slider Setting

		$this->start_controls_section(
			'slider_nft_setting_section',
			[
				'label' => esc_html__( 'Setting', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'nft_autoplay',
			[
					'label' => __('Auto Play?', 'masco-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'masco-hp'),
					'label_off' => __('Hide', 'masco-hp'),
					'return_value' => 'yes',
					'default' => 'yes',
			]
		);

		$this->end_controls_section();

		// start style parts

		// Image
		$this->start_controls_section(
			'nft_card_image',
			[
				'label' => esc_html__( 'Image', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'nft_card_iamge_width',
			[
				'label' => esc_html__( 'Width', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-card-thumb img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'nft_card_height_width',
			[
				'label' => esc_html__( 'Height', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-card-thumb img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'nft_card_image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->end_controls_section();
		// end image style

		// Title
		$this->start_controls_section(
			'ft_card_title_style',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'nft_card_title_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-card-data h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_title_typography',
				'selector' => '{{WRAPPER}} .masco-card-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'nft_card_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-card-data h3',
			]
		);

		$this->add_control(
			'nft_card_title_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-data h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End title style

		// Price 
		$this->start_controls_section(
			'nft_card_price_style',
			[
				'label' => esc_html__( 'Price Title', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'nft_card_price_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-data p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_price_typography',
				'selector' => '{{WRAPPER}} ..masco-card-wrap.masco-card2 .masco-card-data p',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'nft_card_price_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-data p',
			]
		);

		$this->add_control(
			'nft_card_price_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End price style

		// nft card author 
		$this->start_controls_section(
			'nft_card_author_style',
			[
				'label' => esc_html__( 'Author', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'nft_card_author_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-footer-data h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_author_typography',
				'selector' => '{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-footer-data h4',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'nft_card_author_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-footer-data h4',
			]
		);

		$this->add_control(
			'nft_card_author_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-wrap.masco-card2 .masco-card-footer-data h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style

		// nft card button 
		$this->start_controls_section(
			'nft_card_button_style',
			[
				'label' => esc_html__( 'Button', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'nft_card_btn_typography',
				'selector' => '{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'nft_card_btn_background',
				'label' => esc_html__( 'Button Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn',
			]
		);

		$this->add_control(
			'nft_card_btn_color',
			[
				'label' => esc_html__( 'Button Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
				'nft_card_btn_radius',
				[
					'label' => esc_html__( 'Border Radius', 'masco-hp' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		
		$this->add_control(
			'nft_card_author_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End card button style

		// nft card button 
		$this->start_controls_section(
			'nft_card_button_icon_style',
			[
				'label' => esc_html__( 'Button Icon', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_nft_fill_color',
			[
				'label' => esc_html__( 'Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn i' => 'color: {{VALUE}}',
					'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_nft_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'nft_card_btn_icon_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} button.masco-btn.btn-sm.masco-tigger.dark-btn svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End card style

		// nft card box 
		$this->start_controls_section(
			'nft_card_box_style',
			[
				'label' => esc_html__( 'Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'nft_card_box_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-card-wrap.masco-card2',
			]
		);
		$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'nft_card_box_border',
						'label' => esc_html__( 'Border', 'masco-hp' ),
						'selector' => '{{WRAPPER}} .masco-card-wrap.masco-card2',
					]
				);


	$this->add_control(
			'nft_card_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-wrap.masco-card2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			'nft_card_box_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-card-wrap.masco-card2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End card style


		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$masco_nft_card_list = $settings['masco_nft_card_list'];


		 //this code slider option
		 $slider_extraSetting = array(

			'nft_autoplay' => (!empty($settings['nft_autoplay']) && 'yes' === $settings['nft_autoplay']) ? true : false,
			// 'arrows' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);
	

	?>

		<div class="masco-nft-slider">
				<?php foreach ($masco_nft_card_list as $masco_nft_card_lists) : ?>
            <div class="masco-card-wrap masco-card2">
              <div class="masco-card-thumb">
                <img src="<?php echo esc_url($masco_nft_card_lists['masco_nft_card_thumb']['url']) ?>" alt="">
              </div>
              <div class="masco-card-data">
                <h3><?php echo esc_html($masco_nft_card_lists['masco_nft_card_title']) ?></h3>
                <p> <?php \Elementor\Icons_Manager::render_icon($masco_nft_card_lists['masco_nft_card_price_icon'], ['aria-hidden' => 'true']);?> <?php echo esc_html($masco_nft_card_lists['masco_nft_card_price']) ?></p>
                <div class="masco-card-footer">
                  <div class="masco-card-footer-data">
                    <h4><?php echo esc_html($masco_nft_card_lists['masco_nft_card_author']) ?></h4>
                  </div>
                  <button class="masco-btn btn-sm masco-tigger dark-btn" type="button">
                    <?php \Elementor\Icons_Manager::render_icon($masco_nft_card_lists['masco_nft_card_button_icon'], ['aria-hidden' => 'true']);?>
                     <?php echo esc_html($masco_nft_card_lists['masco_nft_card_button']) ?>
                  </button>
                </div>
              </div>
            </div>
        <?php endforeach;?>
    </div>

	<?php
   
 }

}

$widgets_manager->register( new \Masco_Nft_Card_Widget() );