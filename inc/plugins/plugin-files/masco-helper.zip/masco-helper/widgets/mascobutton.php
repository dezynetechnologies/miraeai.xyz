<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Masco_Button_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'masco_button';
	}

	public function get_title() {
		return esc_html__( 'Masco Button', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'button', 'masco', 'link' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'next_button_style',
            [
                'label'             => __( 'Team Style', 'masco-hp' ),
                'type'              => \Elementor\Controls_Manager::SELECT,
                'default'           => 'Default',
                'options'           => [
                    'default'   =>   __('Default',    'masco-hp'),
                    'border-style'   =>   __('Border Style',    'masco-hp'),
                    'button-active'   =>   __('Button Active',    'masco-hp'),
                ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
			'masco_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Button Text', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
			]
		);

		$this->add_control(
			'masco_button_link',
			[
				'label' => esc_html__( 'Button Url', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'masco-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'button_alignment',
			[
				'label' => esc_html__( 'Alignment', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'masco-hp' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'masco-hp' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'masco-hp' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .masco-button-wraper' => 'text-align: {{VALUE}}',
				],
			]
		);



        $this->end_controls_section();
	
			// End button style

        // start button style
    	$this->start_controls_section(
		'masco_button_style',
		[
			'label' => esc_html__( 'Button', 'masco-hp' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'masco-hp' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'selector' => '{{WRAPPER}} .masco-btn',
			]
		);
		$this->add_control(
			'btn_color',
			[
				'label' => esc_html__( 'Button Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-btn.bg-gray' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'btn_background',
				'label' => esc_html__( 'Background Color', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-btn.bg-gray',
			]
		);

		$this->add_responsive_control(
		'btn_width',
		[
			'label' => esc_html__( 'Min Width', 'simple-team-addon' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range' => [
				'px' => [
					'min' => 0,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => '%',
				'size' => 100,
			],
			'selectors' => [
				'{{WRAPPER}} .masco-btn' => 'min-width: {{SIZE}}{{UNIT}};',
			],
		]
	);

		$this->add_responsive_control(
			'btn_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'btn_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'btn_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'masco-hp' ),
			]
		);

		$this->add_control(
			'btn_hover_color',
			[
				'label' => esc_html__( 'Button Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-btn.bg-gray:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tabs();
		
		$this->end_controls_section();

	}

  protected function render() {
    $settings = $this->get_settings_for_display();

     $next_button_style = $settings['next_button_style'];
     $masco_btn_text = $settings['masco_btn_text'];
     $masco_button_link = $settings['masco_button_link'];
		


		?>

            <div class="masco-button-wraper">
                
                <?php 
                    if('default' == $next_button_style){
                     ?>
                       <a class="masco-btn bg-gray" href="<?php echo esc_url($masco_button_link['url']) ?>">
	                        <?php echo esc_html($masco_btn_text) ?>
	                    </a> 
                    <?php
                    }elseif('button-active' == $next_button_style){
                        ?>
                            <a class="masco-btn bg-gray active" href="<?php echo esc_url($masco_button_link['url']) ?>"><span><?php echo esc_html($masco_btn_text) ?></span>
                            </a>
                        <?php
                    }
                    elseif('border-style' == $next_button_style){
                        ?>
                            <a class="masco-outline-btn" href="<?php echo esc_url($masco_button_link['url']) ?>"><span><?php echo esc_html($masco_btn_text) ?></span>
                            </a>
                        <?php
                    }




                ?>

            
            </div>
            
		
		<?php
   
  }

}

$widgets_manager->register( new \Masco_Button_Widget() );