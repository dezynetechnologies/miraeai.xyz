<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Masco_All_demos extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Masco_All_demos';
	}

	public function get_title() {
		return esc_html__( 'All Demos', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'demos', 'thumb' ];
	}

  protected function register_controls() {




		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'flowto_demos_heading',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '10 unique demos', 'masco-hp' ),
				'placeholder' => esc_html__( '10 unique demos', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'flowto_demos_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


    $repeater->add_control(
			'flowto_demos_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Home 01', 'masco-hp' ),
				'placeholder' => esc_html__( 'Home 01', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'flowto_demos_link',
			[
				'label' => esc_html__( 'Demos Url', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'masco-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

	
		$this->add_control(
			'flowto_demos_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'flowto_demos_title' => esc_html__( 'Title', 'masco-hp' ),
						'flowto_demos_thumb' => esc_html__( 'Thumb', 'masco-hp' ),
						'flowto_demos_link' => esc_html__( 'Link', '  masco-hp' ),
					],
				
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_section_btn',
			[
				'label' => esc_html__( 'Button', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


    	$this->add_control(
			'flowto_demos_content',
			[
				'label' => esc_html__( 'Demos Content', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '10 demos', 'masco-hp' ),
				'placeholder' => esc_html__( '10 demos', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'flowto_bay_now',
			[
				'label' => esc_html__( 'Bay Now', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'bay now', 'masco-hp' ),
				'placeholder' => esc_html__( 'bay now', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'flowto_bay_now_link',
			[
				'label' => esc_html__( 'Bay Now Url', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'masco-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);



		$this->end_controls_section();





		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$contents = $settings['flowto_demos_list'];
		$flowto_demos_heading = $settings['flowto_demos_heading'];
		$flowto_demos_content = $settings['flowto_demos_content'];
		$flowto_bay_now = $settings['flowto_bay_now'];
		$flowto_bay_now_link = $settings['flowto_bay_now_link'];

	?>
			<div class="masco-sidemenu-wraper">
				<div class="masco-sidemenu-column">
					<h3 class="masco-sidemenu-title"><?php echo esc_html($flowto_demos_heading) ?></h3>
					<div class="masco-sidemenu-wrap">
	          	<?php foreach ($contents as $content): ?>
	          		<a href="<?php echo esc_url($content['flowto_demos_link']['url']) ?>" class="masco-sidemenu-item">
	          			<img src="<?php echo esc_url($content['flowto_demos_thumb']['url']) ?>" alt="">
			      			<h4><?php echo esc_html($content['flowto_demos_title']) ?></h4>
	          		</a>
	          	<?php endforeach ?>
					</div>
					<span class="masco-sidemenu-close">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M6 18L18 6M6 6L18 18" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
					</span>
				</div>
				<div class="offcanvas-overlay"></div>
				<div class="masco-sidemenu-btn">
					<div class="menu-bar">
						<?php echo esc_html($flowto_demos_content) ?>
					</div>
					<a href="<?php echo esc_url($flowto_bay_now_link['url']) ?>" class="masco-baynow-btn">
				      <?php echo esc_html($flowto_bay_now) ?>
	          </a>
				</div>
			</div>
			
            
			
						





	<?php
   
 }

}

$widgets_manager->register( new \Masco_All_demos() );