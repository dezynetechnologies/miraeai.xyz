<?php

if (!defined('ABSPATH')) {
    exit;
}

class Masco_Icon_Box_Two extends \Elementor\Widget_Base {

	public function get_name() {
		return 'masco_iconboxtwo';
	}

	public function get_title() {
		return esc_html__( 'Masco Icon Box Two', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'iconbox', 'iconboxtwo', 'service', 'service box', 'box'];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);



        $repeater = new \Elementor\Repeater();


		$repeater->add_control(
            'left_icon_show',
            [
                'label' => __('Show left icon', 'masco-hp'),
                'type' =>  \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'finisys'),
                'label_off' => __('No', 'finisys'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
			'box_icon',
			[
				'label' => esc_html__( 'Icon', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => [ 'left_icon_show' => 'yes'],
			],
			
		);

		$repeater->add_control(
			'iconbox_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'iconbox_description',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true
			]
		);
        $repeater->add_control(
			'button_url',
			[
				'label' => esc_html__( 'Readmore Url', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true
			]
		);
		$repeater->add_control(
			'readmore',
			[
				'label' => esc_html__( 'Readmore Icon', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		
		$this->add_control(
			'iconboxtwo',
			[
				'label' => esc_html__( 'Icon Box List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'iconbox_title'        => esc_html__( 'Investment Opportunities', 'masco-hp' ),
						'iconbox_description' => esc_html__( 'We offer individuals the opportunity to invest in early-stage cryptocurrency projects. By participating in an ICO, investors can potentially gain exposure.', 'masco-hp' ),
					],

				
				],
				'title_field' => '{{{ iconbox_title }}}',
			]
		);

		$this->end_controls_section();

        // ICONBOX STYLE
        $this->start_controls_section(
			'iconbox_style',
			[
				'label' => esc_html__( 'Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'box_color',
			[
				'label' => esc_html__( 'Background Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-service-box' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'box_border',
                'label' => __( 'Border', 'masco-hp' ),
                'selector' => '{{WRAPPER}} .masco-service-box',
            ]
		);

		$this->add_responsive_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'box_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'box_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


        $this->end_controls_section();

		// CONTENT BOX STYLE
        $this->start_controls_section(
			'content_box_style',
			[
				'label' => esc_html__( 'Content Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_box_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


        $this->end_controls_section();

        // title style
        $this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-service-text h4' => 'color: {{VALUE}}',
				],
			]
		);
        

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .masco-service-text h4',
			]
		);

        $this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-text h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        
        $this->end_controls_section();


         // description style
         $this->start_controls_section(
			'description_style',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-service-text p' => 'color: {{VALUE}}',
				],
			]
		);
        

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .masco-service-text p',
			]
		);

        $this->add_responsive_control(
			'description_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        
        $this->end_controls_section();


		// ICON style
		$this->start_controls_section(
			'icon_style',
			[
				'label' => esc_html__( 'Icon', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(

            'icon_tabs'

        );

		$this->start_controls_tab(

            'icon_normal_tab',
            [
                'label' => __( 'Normal', 'masco-hp' ),
            ]
        );

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-service-icon svg path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-service-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
            'icon_width',
            [
                'label' => __('Icon width', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .masco-service-icon' => 'width: {{SIZE}}{{UNIT}};',
                ]

            ]
        );

		$this->add_responsive_control(
            'icon_height',
            [
                'label' => __('Icon Height', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .masco-service-icon' => 'height: {{SIZE}}{{UNIT}};',
                ]

            ]
        );

		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-icon a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-service-icon a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(

            'icon_hover_tab',
            [
                'label' => __( 'Hover', 'masco-hp' ),
            ]
        );

		$this->add_control(
			'icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .box-hover:hover .masco-service-icon svg path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_bg_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .box-hover:hover .masco-service-icon' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
            'icon_hover_width',
            [
                'label' => __('Icon width', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .box-hover:hover .masco-service-icon' => 'width: {{SIZE}}{{UNIT}};',
                ]

            ]
        );

		$this->add_responsive_control(
            'icon_hover_height',
            [
                'label' => __('Icon Height', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .box-hover:hover .masco-service-icon' => 'height: {{SIZE}}{{UNIT}};',
                ]

            ]
        );

		$this->add_responsive_control(
			'icon_hover_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-hover:hover .masco-service-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_hover_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-hover:hover .masco-service-icon a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_hover_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-hover:hover .masco-service-icon a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		
	$iconboxtwos = $settings['iconboxtwo'];

	?>

    <?php foreach( $iconboxtwos as $iconbox ): ?>


		
        <div class="masco-service-box box-hover">
			<?php if('yes' == $iconbox['left_icon_show'] ):?>
				<div class="masco-service-image">
					<?php \Elementor\Icons_Manager::render_icon($iconbox['box_icon'], ['aria-hidden' => 'true']);?>
				</div>
			<?php endif; ?>
            <div class="masco-service-text">
                <h4><?php echo esc_html( $iconbox['iconbox_title'] ); ?></h4>
                <p><?php echo esc_html( $iconbox['iconbox_description'] ); ?></p>
            </div>
            <div class="masco-service-icon">
                <a href="<?php echo esc_url( $iconbox['button_url'] ); ?>">
                    <?php \Elementor\Icons_Manager::render_icon($iconbox['readmore'], ['aria-hidden' => 'true']);?> 
                </a>
            </div>
        </div>
    <?php  endforeach; ?>



	<?php
   
 }

}

$widgets_manager->register( new \Masco_Icon_Box_Two() );