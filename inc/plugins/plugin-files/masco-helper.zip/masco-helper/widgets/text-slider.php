<?php


class Masco_Text_Slider_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'masco_text_slider_widget';
	}

	public function get_title() {
		return esc_html__( 'Masco Text Slider', 'masco-addon' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

    $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'masco_text_slider_title',
			[
				'label' => esc_html__( 'Text', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Default title', 'masco-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-addon' ),
				'label_block' => true
			]
		);

		$repeater->add_control(
			'masco_text_slider_icon',
			[
				'label' => esc_html__( 'Icon', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);


		$this->add_control(
			'masco_text_slider_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'masco_text_slider_title' => esc_html__( 'COLLECT RARE AND EXTRAORDINARY ARTWORK', 'masco-addon' ),
						'masco_text_slider_icon' => esc_html__( 'Item content. Click the edit button to change this text.', 'masco-addon' ),
					],
				
				],
				'title_field' => '{{{ masco_text_slider_title }}}',
			]
		);

		$this->end_controls_section();

		// setting slider

		$this->start_controls_section(
			'masco_text_slider_setting',
			[
				'label' => esc_html__( 'Setting', 'masco-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
            'per_coulmn',
            [
                'label' => __('Slider Per Column Items', 'masco-addon'),
                'type' =>  \Elementor\Controls_Manager::SELECT,
                'default'            => 3,
                'tablet_default'     => 2,
                'mobile_default'     => 1,
                'options'            => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                    '7' => '7',
                    '8' => '8',
                    '9' => '9',
                    '10' => '10',
                ],
                'frontend_available' => true,
            ]
        );

		$this->add_responsive_control(
            'slide_scroll',
            [
                'label' => __('Slider Scroll Items', 'mthemeus-addons'),
                'type' =>  \Elementor\Controls_Manager::SELECT,
                'default'            => 1,
                'options'            => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                    '7' => '7',
                    '8' => '8',
                    '9' => '9',
                    '10' => '10',
                ],
                'frontend_available' => true,
            ]
        );

		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay?', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'true', 'masco-addon' ),
				'label_off' => esc_html__( 'false', 'masco-addon' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);

			$this->add_control(
			'speed',
			[
				'label' => __('Autoplay Timeout', 'masco-hp'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => '5000',
				'options' => [
					'1000'  => __('1 Second', 'masco-hp'),
					'2000'  => __('2 Second', 'masco-hp'),
					'3000'  => __('3 Second', 'masco-hp'),
					'4000'  => __('4 Second', 'masco-hp'),
					'5000'  => __('5 Second', 'masco-hp'),
					'6000'  => __('6 Second', 'masco-hp'),
					'7000'  => __('7 Second', 'masco-hp'),
					'8000'  => __('8 Second', 'masco-hp'),
					'9000'  => __('9 Second', 'masco-hp'),
					'10000' => __('10 Second', 'masco-hp'),
					'11000' => __('11 Second', 'masco-hp'),
					'12000' => __('12 Second', 'masco-hp'),
					'13000' => __('13 Second', 'masco-hp'),
					'14000' => __('14 Second', 'masco-hp'),
					'15000' => __('15 Second', 'masco-hp'),
				],
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);


	
		$this->add_control(
			'masco_slider_rtl',
			[
				'label' => esc_html__( 'Rtl?', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'true', 'masco-addon' ),
				'label_off' => esc_html__( 'false', 'masco-addon' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);

		$this->end_controls_section();

		// style part
		// slider text style
		
		// Text
		$this->start_controls_section(
			'masco_text_slider_style',
			[
				'label' => esc_html__( 'Text', 'masco-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'masco_text_slider_color',
			[
				'label' => esc_html__( 'Text Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-data h3' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'masco_text_slider_bg_color',
			[
				'label' => esc_html__( 'Text Background Color', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-data h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'masco_text_slider_typography',
				'selector' => '{{WRAPPER}} .masco-text-slider-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'masco_text_slider_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-addon' ),
				'selector' => '{{WRAPPER}} .masco-text-slider-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'masco_text_slider_border',
				'selector' => '{{WRAPPER}} .masco-text-slider-data h3',
			]
		);

		$this->add_control(
			'masco_text_slider_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-data h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'masco_text_slider_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-data h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Icon
		$this->start_controls_section(
			'masco_icon_slider_style',
			[
				'label' => esc_html__( 'Icon', 'masco-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->start_controls_tabs(
			'masco_style_tabs'
		);

		$this->start_controls_tab(
			'icon_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'masco-addon' ),
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'masco_icon_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-text-slider-icon',
			]
		);
		$this->add_control(
			'masco_icon_slider_fill_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .masco-text-slider-icon path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'masco_icon_slider_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'masco_icon_slide_size',
			[
				'label' => esc_html__( 'Size', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .masco-text-slider-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'masco_icon_slider_width_height',
			[
				'label' => esc_html__( 'Width', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				
				],
		
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'masco_icon_slider_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);


		$this->add_control(
			'masco_icon_slider_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .masco-text-slider-icon svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		
		$this->end_controls_tab();

		// icon hover start

		$this->start_controls_tab(
			'icon_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'masco-addon' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'masco_icon_background_hover',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-text-slider-icon:hover',
			]
		);
		$this->add_control(
			'masco_icon_slider_fill_color_hover',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .masco-text-slider-icon:hover path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'masco_icon_slider_stroke_color_hover',
			[
				'label' => esc_html__( 'Stroke Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-slider-icon:hover path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

  protected function render() {
    	$settings = $this->get_settings_for_display();
		$masco_text_slider_list = $settings['masco_text_slider_list'];

		$slider_rtl = $settings['masco_slider_rtl'];

		if($slider_rtl == 'true'){
			$rtl_open = 'rtl';
		}else{
			$rtl_open = '';
		};


		$slider_extraSetting = array(
			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			'slider_rtl' => (!empty( $slider_rtl) && 'true' ===  $slider_rtl) ? true : false,
			'speed' => !empty($settings['speed']) ? $settings['speed'] : '3000',
			'slide_scroll' => !empty($settings['slide_scroll']) ? $settings['slide_scroll'] : 1,

			//this a responsive layout
			'per_coulmn' => (!empty($settings['per_coulmn'])) ? $settings['per_coulmn'] : 3,
			'per_coulmn_tablet' => (!empty($settings['per_coulmn_tablet'])) ? $settings['per_coulmn_tablet'] : 2,
			'per_coulmn_mobile' => (!empty($settings['per_coulmn_mobile'])) ? $settings['per_coulmn_mobile'] : 1
		);
		$jasondecode = wp_json_encode($slider_extraSetting);


		$this->add_render_attribute('slider_version', 'class', array('masco-text-slider'));
		$this->add_render_attribute('slider_version', 'data-settings', $jasondecode);

	?>

   		<div dir="<?php echo esc_attr($rtl_open); ?>" >
			<div <?php echo $this->get_render_attribute_string('slider_version'); ?> >
				<?php foreach ($masco_text_slider_list as $masco_text_slider_lists) : ?>
						<div class="masco-text-slider-data">

							<div class="masco-text-slider-icon">
								<?php \Elementor\Icons_Manager::render_icon($masco_text_slider_lists['masco_text_slider_icon'], ['aria-hidden' => 'true']);?>
							</div>

							<?php if($masco_text_slider_lists['masco_text_slider_title']): ?>
								<h3>
									<?php echo esc_html($masco_text_slider_lists['masco_text_slider_title'])?>
								</h3>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

		<?php
   
 	 }

}

$widgets_manager->register( new \Masco_Text_Slider_Widget() );