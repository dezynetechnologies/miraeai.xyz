<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Masco_T_Samlple_slider extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Masco_T_slider';
	}

	public function get_title() {
		return esc_html__( 'Masco Testimonial Slider', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
            'tn_align',
            [
                'label' => __('Alignment', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'masco-hp'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'masco-hp'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'masco-hp'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .masco-t-slider-data' => 'text-align: {{VALUE}} !important;',
                ],
            ]
        );



    $repeater = new \Elementor\Repeater();

		// $repeater->add_control(
		// 	'masco_nft_card_thumb',
		// 	[
		// 		'label' => esc_html__( 'Choose Image', 'masco-hp' ),
		// 		'type' => \Elementor\Controls_Manager::MEDIA,
		// 		'default' => [
		// 			'url' => \Elementor\Utils::get_placeholder_image_src(),
		// 		],
		// 	]
		// );

    	$repeater->add_control(
            'masco_t_rating_icon',
            [
                'label' => __('Rating Icon', 'masco'),
                'label_block' => false,
                'type' => \Elementor\Controls_Manager::ICONS,
                'skin' => 'inline',
                'default' => [
                    'value' => 'fas fa-chevron-left',
                    'library' => 'fa-solid',
                ],
             
            ]
        );


     $repeater->add_control(
            'masco_t_rating',
            [
                'label'     => __( 'Customar Rating', 'masco' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => '5',
                'options'   => [
                    'none' => __( 'none', 'masco' ),
                    '1'    => __( '1', 'masco' ),
                    '2'    => __( '2', 'masco' ),
                    '3'    => __( '3', 'masco' ),
                    '4'    => __( '4', 'masco' ),
                    '5'    => __( '5', 'masco' ),
                ],
                
            ]
        );



		$repeater->add_control(
			'masco_t_title',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_t_description',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Masco is an excellent company. in everything uptime, fast technical support, sales, & billing-friendly people. If you want to open a web solutions must register.', 'masco-hp' ),
				'label_block' => true
			]
		);
	
		$repeater->add_control(
			'masco_t_author_name',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Price Title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_t_author_designation',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Founder @ Company', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'masco_t_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'masco_t_title' => esc_html__( 'Title', 'masco-hp' ),
						'masco_t_description' => esc_html__( 'Description', 'masco-hp' ),
						'masco_t_author_name' => esc_html__( 'Karen Lynn', 'masco-hp' ),
						'masco_t_author_designation' => esc_html__( 'Founder @ Company', 'masco-hp' ),
						'masco_t_rating' => esc_html__( '5', 'masco-hp' ),
					],
				
				],
				'title_field' => '{{{ masco_t_title }}}',
			]
		);

		$this->end_controls_section();

		// slider Setting

		$this->start_controls_section(
			't_slider_setting_section',
			[
				'label' => esc_html__( 'Setting', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
					'label' => __('Auto Play?', 'masco-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'masco-hp'),
					'label_off' => __('Hide', 'masco-hp'),
					'return_value' => 'yes',
					'default' => 'no',
			]
		);

		$this->add_control(
            'dots',
            [
                'label' => __('Show Dots?', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'masco-hp'),
                'label_off' => __('Hide', 'masco-hp'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

		$this->end_controls_section();

		// start style parts

		// Image
		// $this->start_controls_section(
		// 	'nft_card_image',
		// 	[
		// 		'label' => esc_html__( 'Image', 'masco-hp' ),
		// 		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		// 	]
		// );

		// $this->add_responsive_control(
		// 	'nft_card_iamge_width',
		// 	[
		// 		'label' => esc_html__( 'Width', 'masco-hp' ),
		// 		'type' => \Elementor\Controls_Manager::SLIDER,
		// 		'size_units' => [ 'px', '%' ],
		// 		'range' => [
		// 			'px' => [
		// 				'min' => 0,
		// 				'max' => 1000,
		// 				'step' => 5,
		// 			],
		// 			'%' => [
		// 				'min' => 0,
		// 				'max' => 100,
		// 			],
		// 		],
		// 		'default' => [
		// 			'unit' => '%',
		// 			'size' => 100,
		// 		],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .masco-card-thumb img' => 'width: {{SIZE}}{{UNIT}};',
		// 		],
		// 	]
		// );

		// $this->add_responsive_control(
		// 	'nft_card_height_width',
		// 	[
		// 		'label' => esc_html__( 'Height', 'masco-hp' ),
		// 		'type' => \Elementor\Controls_Manager::SLIDER,
		// 		'size_units' => [ 'px', '%' ],
		// 		'range' => [
		// 			'px' => [
		// 				'min' => 0,
		// 				'max' => 1000,
		// 				'step' => 5,
		// 			],
		// 			'%' => [
		// 				'min' => 0,
		// 				'max' => 100,
		// 			],
		// 		],
		// 		'default' => [
		// 			'unit' => '%',
		// 			'size' => 100,
		// 		],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .masco-card-thumb img' => 'height: {{SIZE}}{{UNIT}};',
		// 		],
		// 	]
		// );

		// $this->add_control(
		// 	'nft_card_image_border_radius',
		// 	[
		// 		'label' => esc_html__( 'Border Radius', 'masco-hp' ),
		// 		'type' => \Elementor\Controls_Manager::DIMENSIONS,
		// 		'size_units' => [ 'px', '%', 'em' ],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .masco-card-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		// 		],
		// 		'separator' => 'before'
		// 	]
		// );
		// $this->end_controls_section();
		// end image style

		// Title
		$this->start_controls_section(
			't_title_style',
			[
				'label' => esc_html__( 'Title', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_title_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-data h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_title_typography',
				'selector' => '{{WRAPPER}} .masco-t-slider-data h3',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_title_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-data h3',
			]
		);

		$this->add_control(
			't_title_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-data h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End title style

		// Description 
		$this->start_controls_section(
			't_des_style',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_des_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-data p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_des_typography',
				'selector' => '{{WRAPPER}} .masco-t-slider-data p',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_des_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-data p',
			]
		);

		$this->add_control(
			't_des_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End Description style

		//  author 
		$this->start_controls_section(
			't_author_style',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_typography',
				'selector' => '{{WRAPPER}} .masco-t-author-data h4',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-author-data h4',
			]
		);

		$this->add_control(
			't_author_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style

		// nft card author 
		$this->start_controls_section(
			't_author_designation_style',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_designation_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_designation_typography',
				'selector' => '{{WRAPPER}} .masco-t-author-data span',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_designation_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-author-data span',
			]
		);

		$this->add_control(
			't_author_designation_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style



		   //icon style
        $this->start_controls_section(
            'icon_style',
            [
                'label' => __('Rating', 'masco-hp'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'icon_style_tabs'
        );

        // hover
        $this->start_controls_tab(
            'tab_icon_normal_color',
            [
                'label' => __('Normal', 'masco'),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => __('Active Color', 'masco-hp'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .masco--tn-review .active_color' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .masco--tn-review svg' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .masco--tn-review svg path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_inactive_color',
            [
                'label'     => __('Inactive Color', 'masco-hp'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .masco--tn-review .inactive_color' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .masco--tn-review svg' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .masco--tn-review svg path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'line_icon_color',
            [
                'label'     => __('Line Color', 'masco-hp'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .masco--tn-review i,
                    {{WRAPPER}} .masco--tn-review svg' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .masco--tn-review svg path' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'fd_addons_position_rating_type',
            [
                'label'       => __('Position Type', 'fd-addons'),
                'label_block' => true,
                'type'        => \Elementor\Controls_Manager::SELECT,
                'options'     => [
                    ''         => __('Default', 'fd-addons'),
                    'static'   => __('Static', 'fd-addons'),
                    'relative' => __('Relative', 'fd-addons'),
                    'absolute' => __('Absolute', 'fd-addons'),

                ],
                'default'     => '',
                'selectors'   => [
                    '{{WRAPPER}} .masco--tn-review' => 'position:{{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'fd_addons_position_rating_top',
            [
                'label'      => __('Top', 'fd-addons'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => -2000,
                        'max'  => 2000,
                        'step' => 1,

                    ],
                    '%'  => [
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => -150,
                        'max'  => 150,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .masco--tn-review' => 'top:{{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'fd_addons_position_rating_type' => ['relative', 'absolute'],
                ],
            ]
        );

        $this->add_responsive_control(
            'fd_addons_position_rating__right',
            [
                'label'        => __('Right', 'fd-addons'),
                'type'         => \Elementor\Controls_Manager::SLIDER,
                'size_units'   => ['px', 'em', '%'],
                'range'        => [
                    'px' => [
                        'min'  => -2000,
                        'max'  => 2000,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => -150,
                        'max'  => 150,
                        'step' => 1,
                    ],
                ],
                'selectors'    => [
                    '{{WRAPPER}} .masco--tn-review' => 'right:{{SIZE}}{{UNIT}};',
                ],
                'condition'    => [
                    'fd_addons_position_rating_type' => ['relative', 'absolute'],
                ],
                'return_value' => '',
            ]
        );


        $this->add_responsive_control(
            'fd_addons_position_rating_bottom',
            array(
                'label'      => __('Bottom', 'fd-addons'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array('px', 'em', '%'),
                'range'      => array(
                    'px' => array(
                        'min'  => -2000,
                        'max'  => 2000,
                        'step' => 1,
                    ),
                    '%'  => array(
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1,
                    ),
                    'em' => array(
                        'min'  => -150,
                        'max'  => 150,
                        'step' => 1,
                    ),
                ),

                'selectors'  => array(
                    '{{WRAPPER}} .masco--tn-review' => 'bottom:{{SIZE}}{{UNIT}};',
                ),
                'condition'  => array(
                    'fd_addons_position_rating_type' => array('relative', 'absolute'),
                ),
            )
        );

        $this->add_responsive_control(
            'fd_addons_position_rating_left',
            array(
                'label'      => __('Left', 'fd-addons'),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array('px', 'em', '%'),
                'range'      => array(
                    'px' => array(
                        'min'  => -2000,
                        'max'  => 2000,
                        'step' => 1,
                    ),
                    '%'  => array(
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1,
                    ),
                    'em' => array(
                        'min'  => -150,
                        'max'  => 150,
                        'step' => 1,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .masco--tn-review' => 'left:{{SIZE}}{{UNIT}};',
                ),
                'condition'  => array(
                    'fd_addons_position_rating_type' => array('relative', 'absolute'),
                ),
            )
        );

        $this->add_responsive_control(
            'fd_addons_position_from_rating_center',
            array(
                'label'       => __('From Center', 'fd-addons'),
                'description' => __('Please avoid using "From Center" and "Left" options at the same time.', 'fd-addons'),
                'type'        => \Elementor\Controls_Manager::SLIDER,
                'size_units'  => array('px', 'em', '%'),
                'range'       => array(
                    'px' => array(
                        'min'  => -1000,
                        'max'  => 1000,
                        'step' => 1,
                    ),
                    '%'  => array(
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1,
                    ),
                    'em' => array(
                        'min'  => -150,
                        'max'  => 150,
                        'step' => 1,
                    ),
                ),

                'selectors'   => array(
                    '{{WRAPPER}} .masco--tn-review' => 'left:calc( 50% + {{SIZE}}{{UNIT}} );',
                ),
                'condition'   => array(
                    'fd_addons_position_rating_type' => array('relative', 'absolute'),
                ),
            )
        );

        $this->add_responsive_control(
            'fd_addons_position_rating_zindex',
            array(
                'label'     => __('Z-Index', 'fd-addons'),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'default'   => '',
                'selectors' => array(
                    '{{WRAPPER}} .masco--tn-review' => 'z-index:{{VALUE}};',
                ),
            ),

        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_icon_hover_color',
            [
                'label' => __('Hover', 'masco'),
            ]
        );
        $this->add_control(
            'icon_color_hover',
            [
                'label'     => __('Hover Color', 'masco-hp'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-v2-tab__single:hover .masco--tn-review i,
                    {{WRAPPER}} .testimonial-v2-tab__single:hover .masco--tn-review svg' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-v2-tab__single:hover .masco--tn-review svg path' => 'fill: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_color_line_hover',
            [
                'label'     => __('Hover Line Color', 'masco-hp'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-v2-tab__single:hover .masco--tn-review i,
                    {{WRAPPER}} .testimonial-v2-tab__single:hover .masco--tn-review svg' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-v2-tab__single:hover .masco--tn-review svg path' => 'stroke: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'icon_size',
            [
                'label'          => __('Size', 'masco-hp'),
                'type'           => \Elementor\Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => 'px',
                ],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .masco--tn-review i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .masco--tn-review svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


        $this->add_responsive_control(
            'icon_right_gap',
            [
                'label'          => __('Right Gap', 'masco-hp'),
                'type'           => \Elementor\Controls_Manager::SLIDER,
                'default'        => [
                    'unit' => 'px',
                ],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .masco--tn-review i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label'      => __('Margin', 'masco-hp'),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .masco--tn-review' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    'body.rtl {{WRAPPER}} .masco--tn-review' => 'margin: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


		

		
		//  box 
		$this->start_controls_section(
			't_box_style',
			[
				'label' => esc_html__( 'Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 't_box_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-t-slider-data',
			]
		);
		$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 't_box_border',
						'label' => esc_html__( 'Border', 'masco-hp' ),
						'selector' => '{{WRAPPER}} .masco-t-slider-data',
					]
				);


	$this->add_control(
			't_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-data' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			't_box_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End box style


		    /*
        * ============================= Dots Style ==============================================
        */
        $this->start_controls_section(
					'dots_navigation',
					[
							'label' => __('Navigation - Dots', 'wybe-hp'),
							'tab' => \Elementor\Controls_Manager::TAB_STYLE,
					]
			);
			$this->start_controls_tabs('_tabs_dots');

			$this->start_controls_tab(
					'_tab_dots_normal',
					[
							'label' => __('Normal', 'wybe-hp'),
					]
			);

			$this->add_control(
					'dots_color',
					[
							'label' => __('Color', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li' => 'background-color: {{VALUE}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_box_width',
					[
							'label' => __('Width', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li' => 'width: {{SIZE}}{{UNIT}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_box_height',
					[
							'label' => __('Height', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li' => 'height: {{SIZE}}{{UNIT}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_margin',
					[
							'label'          => __('Gap Right', 'wybe-hp'),
							'type'           => \Elementor\Controls_Manager::SLIDER,
							'default'        => [
									'unit' => 'px',
							],
							'range'          => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors'      => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li' => 'margin-right: {{SIZE}}{{UNIT}};',
									'body.rtl {{WRAPPER}} .masco-t-slider .slick-dots li' => 'margin-left: {{SIZE}}{{UNIT}};',
							],
					]
			);
			$this->add_responsive_control(
					'dots_min_padding',
					[
							'label'      => __('Margin', 'wybe-hp'),
							'type'       => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => ['px', '%'],
							'selectors'  => [
									'{{WRAPPER}} .masco-t-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
									'body.rtl {{WRAPPER}} .masco-t-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}} !important;',
							],
					]
			);
			$this->add_responsive_control(
					'dots_border_radius',
					[
							'label'      => __('Border Radius', 'wybe-hp'),
							'type'       => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => ['px', '%'],
							'selectors'  => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
									'body.rtl {{WRAPPER}} .masco-t-slider .slick-dots li' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
							],
					]
			);
			$this->end_controls_tab();

					// ======================= Dots Active Style =======================================

			$this->start_controls_tab(
					'_tab_dots_active',
					[
							'label' => __('Active', 'wybe-hp'),
					]
			);
			$this->add_control(
					'dots_color_active',
					[
							'label' => __('Active Color', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li.slick-active ' => 'background-color: {{VALUE}}  !important;',
							],
					]
			);

			$this->add_responsive_control(
					'arrow_dots_box_active_width',
					[
							'label' => __('Width', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li.slick-active ' => 'width: {{SIZE}}{{UNIT}} !important;',
							],
					]
			);

			$this->add_responsive_control(
					'arrow_dots_box_active_height',
					[
							'label' => __('Height', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-slider .slick-dots li.slick-active ' => 'height: {{SIZE}}{{UNIT}} !important;',
							],
					]
			);
			$this->end_controls_tab();
			$this->end_controls_tabs();
			$this->end_controls_section();



		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$masco_t_list = $settings['masco_t_list'];


		 //this code slider option
		 $slider_extraSetting = array(

			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,
			// 'arrows' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);

		$this->add_render_attribute('masco_t_slider', 'class', array('masco-t-slider', 't-style'));
		$this->add_render_attribute('masco_t_slider', 'data-settings', $jasondecode);
	

	?>
		<section class="section">
			<div <?php echo $this->get_render_attribute_string('masco_t_slider'); ?>>
				<?php foreach ($masco_t_list as $masco_t_lists) : ?>
		            <div class="masco-t-slider-wrap">
		              <div class="masco-t-slider-data">
		              	<div class="masco--tn-review">
		              		<?php for($i=0;$i<5;$i++): 
				                	$class = '';
				                ?>
				                <?php if ($masco_t_lists['masco_t_rating'] > $i) {
				                    $class = "active_color";
				                } ?>
				                <span class="inactive_color">
				                	<?php \Elementor\Icons_Manager::render_icon($masco_t_lists['masco_t_rating_icon'], [ 'class' => $class,'aria-hidden' => 'true']) ?>
				                	
				                </span>
				            <?php endfor; ?>
		              	</div>
		                <h3><?php echo esc_html($masco_t_lists['masco_t_title']) ?></h3>
		                <p><?php echo esc_html($masco_t_lists['masco_t_description']) ?></p>
		                <div class="masco-t-author-data">
		                   <h4><?php echo esc_html($masco_t_lists['masco_t_author_name']) ?></h4>
		                   <span><?php echo esc_html($masco_t_lists['masco_t_author_designation']) ?></span>
		                </div>
		              </div>
	            	</div>
	        	<?php endforeach;?>
	        </div>
		</section>

	<?php
   
 }

}

$widgets_manager->register( new \Masco_T_Samlple_slider() );