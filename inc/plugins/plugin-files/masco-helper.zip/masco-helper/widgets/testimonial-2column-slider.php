<?php

	if (!defined('ABSPATH')) {
		exit;
	}

class Masco_T_2Column_slider extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Masco_Two_Column_Slider';
	}

	public function get_title() {
		return esc_html__( 'Masco Testimonial Two Column Slider', 'masco-hp' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'testimonial_version',
			[
				'label' => esc_html__( 'Version', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-one',
				'options' => [
					'style-one' => esc_html__( 'Style One', 'textdomain' ),
					'style-two' => esc_html__( 'Style Two', 'textdomain' ),
				],
			]
		);


        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'masco_t_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'masco_t_description',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Masco is an excellent company. in everything uptime, fast technical support, sales, & billing-friendly people. If you want to open a web solutions must register.', 'masco-hp' ),
				'label_block' => true
			]
		);
	
		$repeater->add_control(
			'masco_t_author_name',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Price Title', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'masco_t_author_designation',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Founder @ Company', 'masco-hp' ),
				'placeholder' => esc_html__( 'Type your title here', 'masco-hp' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'masco_t_list',
			[
				'label' => esc_html__( 'Repeater List', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'masco_t_description' => esc_html__( 'Description', 'masco-hp' ),
						'masco_t_author_name' => esc_html__( 'Karen Lynn', 'masco-hp' ),
						'masco_t_author_designation' => esc_html__( 'Founder @ Company', 'masco-hp' ),
					],
				
				],
				'title_field' => '{{{ masco_t_author_name }}}',
			]
		);

		$this->end_controls_section();


		// slider arrow

		$this->start_controls_section(
			'slider_content_section',
			[
				'label' => esc_html__( 'Arrows', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'arrow_prev_icon',
			[
				'label' => esc_html__( 'Slider Icon Left', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'arrow_next_icon',
			[
				'label' => esc_html__( 'Slider Icon Right', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->end_controls_section();


		// slider Setting

		$this->start_controls_section(
			't_slider_setting_section',
			[
				'label' => esc_html__( 'Setting', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
					'label' => __('Auto Play?', 'masco-hp'),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __('Show', 'masco-hp'),
					'label_off' => __('Hide', 'masco-hp'),
					'return_value' => 'yes',
					'default' => 'no',
			]
		);

		$this->add_control(
            'dots',
            [
                'label' => __('Show Dots?', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'masco-hp'),
                'label_off' => __('Hide', 'masco-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'arrows',
            [
                'label' => __('Show Arrows?', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'masco-hp'),
                'label_off' => __('Hide', 'masco-hp'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

		$this->end_controls_section();

		// start style parts

		// Image
		$this->start_controls_section(
			'masco_t__thumb',
			[
				'label' => esc_html__( 'Image', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			't_thumb_width',
			[
				'label' => esc_html__( 'Width', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-thumb img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			't_thumb_height_width',
			[
				'label' => esc_html__( 'Height', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-thumb img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 't_thumb_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-thumb img',
			]
		);

		$this->add_responsive_control(
			't_thumb_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);
		$this->add_responsive_control(
			't_thumb_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-thumb' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// end image style

	

		// Description 
		$this->start_controls_section(
			't_des_style',
			[
				'label' => esc_html__( 'Description', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_des_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-2column-slider-data p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_des_typography',
				'selector' => '{{WRAPPER}} .masco-t-2column-slider-data p',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_des_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-2column-slider-data p',
			]
		);

		$this->add_control(
			't_des_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-2column-slider-data p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// End Description style

		//  author 
		$this->start_controls_section(
			't_author_style',
			[
				'label' => esc_html__( 'Author Name', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_typography',
				'selector' => '{{WRAPPER}} .masco-t-author-data h4',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-author-data h4',
			]
		);

		$this->add_control(
			't_author_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style

		// star  author  Designation
		$this->start_controls_section(
			't_author_designation_style',
			[
				'label' => esc_html__( 'Author Designation', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			't_author_designation_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 't_author_designation_typography',
				'selector' => '{{WRAPPER}} .masco-t-author-data span',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 't_author_designation_text_shadow',
				'label' => esc_html__( 'Text Shadow', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-author-data span',
			]
		);

		$this->add_control(
			't_author_designation_margin',
			[
				'label' => esc_html__( 'Margin', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-author-data span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End author style



		//  box 
		$this->start_controls_section(
			't_box_style',
			[
				'label' => esc_html__( 'Box', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 't_box_background',
				'label' => esc_html__( 'Background', 'masco-hp' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .masco-t-2column-slider-data',
			]
		);
		$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 't_box_border',
						'label' => esc_html__( 'Border', 'masco-hp' ),
						'selector' => '{{WRAPPER}} .masco-t-2column-slider-data',
					]
				);


	$this->add_control(
			't_box_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-2column-slider-data' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			't_box_padding',
			[
				'label' => esc_html__( 'Padding', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-2column-slider-data' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		// End box style


		    /*
        * ============================= Dots Style ==============================================
        */
        $this->start_controls_section(
					'dots_navigation',
					[
							'label' => __('Navigation - Dots', 'wybe-hp'),
							'tab' => \Elementor\Controls_Manager::TAB_STYLE,
					]
			);
			$this->start_controls_tabs('_tabs_dots');

			$this->start_controls_tab(
					'_tab_dots_normal',
					[
							'label' => __('Normal', 'wybe-hp'),
					]
			);

			$this->add_control(
					'dots_color',
					[
							'label' => __('Color', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'background-color: {{VALUE}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_box_width',
					[
							'label' => __('Width', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'width: {{SIZE}}{{UNIT}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_box_height',
					[
							'label' => __('Height', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'height: {{SIZE}}{{UNIT}};',
							],
					]
			);

			$this->add_responsive_control(
					'dots_margin',
					[
							'label'          => __('Gap Right', 'wybe-hp'),
							'type'           => \Elementor\Controls_Manager::SLIDER,
							'default'        => [
									'unit' => 'px',
							],
							'range'          => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors'      => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'margin-right: {{SIZE}}{{UNIT}};',
									'body.rtl {{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'margin-left: {{SIZE}}{{UNIT}};',
							],
					]
			);
			$this->add_responsive_control(
					'dots_min_padding',
					[
							'label'      => __('Margin', 'wybe-hp'),
							'type'       => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => ['px', '%'],
							'selectors'  => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
									'body.rtl {{WRAPPER}} .masco-t-2column-slider .slick-dots' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}} !important;',
							],
					]
			);
			$this->add_responsive_control(
					'dots_border_radius',
					[
							'label'      => __('Border Radius', 'wybe-hp'),
							'type'       => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => ['px', '%'],
							'selectors'  => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
									'body.rtl {{WRAPPER}} .masco-t-2column-slider .slick-dots li' => 'border-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
							],
					]
			);
			$this->end_controls_tab();

					// ======================= Dots Active Style =======================================

			$this->start_controls_tab(
					'_tab_dots_active',
					[
							'label' => __('Active', 'wybe-hp'),
					]
			);
			$this->add_control(
					'dots_color_active',
					[
							'label' => __('Active Color', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li.slick-active ' => 'background-color: {{VALUE}}  !important;',
							],
					]
			);

			$this->add_responsive_control(
					'arrow_dots_box_active_width',
					[
							'label' => __('Width', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li.slick-active ' => 'width: {{SIZE}}{{UNIT}} !important;',
							],
					]
			);

			$this->add_responsive_control(
					'arrow_dots_box_active_height',
					[
							'label' => __('Height', 'wybe-hp'),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => ['px'],
							'range' => [
									'px' => [
											'min' => 0,
											'max' => 200,
									],
							],
							'selectors' => [
									'{{WRAPPER}} .masco-t-2column-slider .slick-dots li.slick-active ' => 'height: {{SIZE}}{{UNIT}} !important;',
							],
					]
			);
			$this->end_controls_tab();
			$this->end_controls_tabs();
			$this->end_controls_section();



		// slider arrows
		$this->start_controls_section(
			'icon_style_section',
			[
				'label' => esc_html__( 'Arrows', 'card-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'arrows_style_tabs'
		);

		$this->start_controls_tab(
			'arrow_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'card-addon' ),
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrow_background',
				'label' => esc_html__( 'Background', 'card-addon' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .masco-t-slider-arrow button',
			]
		);

		$this->add_control(
			'arrow_fill_color',
			[
				'label' => esc_html__( 'Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .masco-t-slider-arrow button path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrow_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_width',
			[
				'label' => esc_html__( 'Width', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				
				],
		
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_control(
			'arrows_size',
			[
				'label' => esc_html__( 'Size', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .masco-t-slider-arrow button svg' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 't_arrows_border',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-arrow button',
			]
		);

		$this->add_control(
			'arrows_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'card-addon' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-arrow button',
			]
		);

		$this->end_controls_tab();

		// icon hover

		$this->start_controls_tab(
			'arrows_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'card-addon' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'arrows_hover_background',
				'label' => esc_html__( 'Background', 'card-addon' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .masco-t-slider-arrow button:hover',
			]
		);

		$this->add_control(
			'arrows_hover_fill_color',
			[
				'label' => esc_html__( 'Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button:hover i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .masco-t-slider-arrow button:hover path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'arrows_hover_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'card-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-t-slider-arrow button:hover path' => 'stroke: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 't_arrows_border_hover',
				'label' => esc_html__( 'Border', 'masco-hp' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-arrow button:hover',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'arrows_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'card-addon' ),
				'selector' => '{{WRAPPER}} .masco-t-slider-arrow button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();



		

	}

  protected function render() {
    $settings = $this->get_settings_for_display();
		$masco_t_list = $settings['masco_t_list'];
		$arrow_prev_icon = $settings['arrow_prev_icon'];
		$arrow_next_icon = $settings['arrow_next_icon'];


		 //this code slider option
		 $slider_extraSetting = array(

			'autoplay' => (!empty($settings['autoplay']) && 'yes' === $settings['autoplay']) ? true : false,
			'dots' => (!empty($settings['dots']) && 'yes' === $settings['dots']) ? true : false,
			'arrows' => (!empty($settings['arrows']) && 'yes' === $settings['arrows']) ? true : false,

		);

		$jasondecode = wp_json_encode($slider_extraSetting);


		$this->add_render_attribute('masco_t_2column__slider', 'class', array('masco-t-2column-slider', 't-style'));
		$this->add_render_attribute('masco_t_2column__slider', 'data-settings', $jasondecode);
	

	?>
		<section class="section">
			<div <?php echo $this->get_render_attribute_string('masco_t_2column__slider'); ?>>
				<?php if( $settings[ "testimonial_version" ] == "style-one" ) : ?>
					<?php foreach ($masco_t_list as $masco_t_lists) : ?>
						<div class="masco-t-2column-slider-wrap">
							<div class="row">
								<div class="col-xl-3 col-lg-4">
									<div class="masco-t-slider-thumb">
										<img src="<?php echo esc_url($masco_t_lists['masco_t_thumb']['url']) ?>" alt="">
									</div>
								</div>
								<div class="col-xl-9 col-lg-8 d-flex align-items-center">
									<div class="masco-t-2column-slider-data">
									<p><?php echo esc_html($masco_t_lists['masco_t_description']) ?></p>
									<div class="masco-t-author-data">
										<h4><?php echo esc_html($masco_t_lists['masco_t_author_name']) ?></h4>
										<span><?php echo esc_html($masco_t_lists['masco_t_author_designation']) ?></span>
									</div>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach;?>
				<?php elseif( $settings[ "testimonial_version" ] == "style-two" ):  ?>
					<?php foreach ($masco_t_list as $masco_t_lists) : ?>
						<div class="masco-t-2column-slider-wrap">
							<div class="row">
								<div class="col-xl-4 col-lg-4">
									<div class="masco-t-slider-thumb">
										<img src="<?php echo esc_url($masco_t_lists['masco_t_thumb']['url']) ?>" alt="">
									</div>
								</div>
								<div class="col-xl-8 col-lg-8 d-flex align-items-center">
									<div class="masco-t-2column-slider-data">
									<p><?php echo esc_html($masco_t_lists['masco_t_description']) ?></p>
									<div class="masco-t-author-data">
										<h4><?php echo esc_html($masco_t_lists['masco_t_author_name']) ?></h4>
										<span><?php echo esc_html($masco_t_lists['masco_t_author_designation']) ?></span>
									</div>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach;?>
				<?php endif;  ?>
	        </div>
		</section>

		<?php if ( 'yes' == $settings['arrows']): ?> 
			<div class="masco-t-slider-arrow">
				<?php if (!empty($settings['arrow_prev_icon']['value'])) : ?>
						<button type="button" class="slick-prev prev slick-arrow slick-active">
							<?php \Elementor\Icons_Manager::render_icon($arrow_prev_icon, ['aria-hidden' => 'true']);?>
						</button>
				<?php endif; ?>

				<?php if (!empty($settings['arrow_next_icon']['value'])) : ?>
						<button type="button" class="slick-next next slick-arrow ">
							<?php \Elementor\Icons_Manager::render_icon($arrow_next_icon, ['aria-hidden' => 'true']);?>
						</button>
				<?php endif; ?>
			</div>
		<?php endif; ?>



	<?php
   
 }

}

$widgets_manager->register( new \Masco_T_2Column_slider() );