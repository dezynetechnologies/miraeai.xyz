<?php


class Masco_Text_Circle_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'masco_text_circle_widget';
	}

	public function get_title() {
		return esc_html__( 'Masco Text Circle', 'masco-addon' );
	}

	public function get_icon() {
		return 'eicon-post-slider';
	}

	public function get_categories() {
		return [ 'masco-addons' ];
	}

	public function get_keywords() {
		return [ 'text', 'animate', 'infinite', ' slider' ];
	}

  protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'masco-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
            'tn_align',
            [
                'label' => __('Alignment', 'masco-hp'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'masco-hp'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'masco-hp'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'masco-hp'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .masco-text-circle-wrap' => 'text-align: {{VALUE}} !important;',
                ],
            ]
        );


		$this->add_control(
			'masco_text_circle_icon',
			[
				'label' => esc_html__( 'Icon', 'masco-addon' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$this->add_control(
			'masco_text_circle',
			[
				'label' => esc_html__( 'Choose Image', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'masco_text_circle_link',
			[
				'label' => esc_html__( 'Url', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'masco-hp' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);


		$this->end_controls_section();


		// style


		// Image
		$this->start_controls_section(
			'masco_text_circle_thumb',
			[
				'label' => esc_html__( 'Image', 'masco-hp' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);



		$this->add_responsive_control(
			'masco_text_circle_width',
			[
				'label' => esc_html__( 'Width', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				// 'default' => [
				// 	'unit' => '%',
				// 	'size' => 100,
				// ],
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'masco_text_circle_height_width',
			[
				'label' => esc_html__( 'Height', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				// 'default' => [
				// 	'unit' => '%',
				// 	'size' => 100,
				// ],
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		
		

		$this->end_controls_section();

		// Icon
		$this->start_controls_section(
			'masco_text_circle_icon_style',
			[
				'label' => esc_html__( 'Icon', 'masco-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->start_controls_tabs(
			'masco_style_tabs'
		);

		$this->start_controls_tab(
			'icon_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'masco-addon' ),
			]
		);

		

		$this->add_control(
			'masco_text_circle_icon__fill_color',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .masco-text-circle-icon path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'masco_text_circle_icon_stroke_color',
			[
				'label' => esc_html__( 'Stroke Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle-icon path' => 'stroke: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'masco_text_circle_size',
			[
				'label' => esc_html__( 'Size', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .masco-text-circle-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before'
			]
		);

		$this->end_controls_tab();


			// icon hover start

		$this->start_controls_tab(
			'icon_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'masco-addon' ),
			]
		);

		$this->add_control(
			'masco_text_circle_icon_fill_color_hover',
			[
				'label' => esc_html__( 'Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle:hover .masco-text-circle-icon i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .masco-text-circle:hover .masco-text-circle-icon path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'masco_text_circle_icon_stroke_color_hover',
			[
				'label' => esc_html__( 'Stroke Color', 'masco-hp' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .masco-text-circle:hover .masco-text-circle-icon path' => 'stroke: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();


		$this->end_controls_section();

	}

  protected function render() {
    	$settings = $this->get_settings_for_display();
		$masco_text_circle_icon = $settings['masco_text_circle_icon'];
		$masco_text_circle = $settings['masco_text_circle'];
		$masco_text_circle_link = $settings['masco_text_circle_link'];



	?>

	<div class="masco-text-circle-wrap">
		<a href="<?php echo esc_url($masco_text_circle_link['url']) ?>">
			<div class="masco-text-circle">
				<img src="<?php echo esc_url($settings['masco_text_circle']['url']) ?>" alt="">
				<div class="masco-text-circle-icon">
					<?php \Elementor\Icons_Manager::render_icon($settings['masco_text_circle_icon'], ['aria-hidden' => 'true']);?>
				</div>
			</div>
		</a>
		
	</div>
				



		<?php
   
 	 }

}

$widgets_manager->register( new \Masco_Text_Circle_Widget() );