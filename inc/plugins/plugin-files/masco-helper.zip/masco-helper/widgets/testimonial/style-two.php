<?php 
use Elementor\Icons_Manager;
?>

<div class="masco--tn-single <?php echo esc_attr( $testimonial_style ); ?>">

    <div class="masco--tn-top">
        <?php if(has_post_thumbnail() ): ?>
            <div class="masco--t-thumb">
                <?php the_post_thumbnail( 'medium' ) ?>  
            </div>
        <?php endif; ?>
    </div>
    
    <div class="masco-tn-bottom-style-two">
        <div class="masco--tn-name-title">
            <h4 class="masco--tn-name">
                <?php the_title() ?>
            </h4>

            <?php if(function_exists('the_field') ):?>
                <span class="masco--tn-title">
                    <?php echo get_field('designation') ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if(function_exists('the_field') ):    
            $ratting = get_field('review_rating');
        ?>
        <div class="masco--tn-icon">
            <?php for($i=0;$i<$ratting;$i++): ?>
                <?php Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']) ?>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

    <div class="masco--tn-dis">
        <?php echo masco_get_meta( $content );?>
    </div>
</div>